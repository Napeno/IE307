//21522029 Nguyễn Sơn Hà
import * as SQLite from "expo-sqlite"
export const db = SQLite.openDatabase("ie307")
