import { SafeAreaView, View, Text, StyleSheet } from "react-native";
import styles from '../../styles/home'

export const Categories = () => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.viewContainer}>
        <Text style={styles.text}>Categories Screen</Text>
      </View>
    </SafeAreaView>
  );
};

