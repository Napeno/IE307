import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    paddingTop: 50, 
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  darkContainer: {
    backgroundColor: '#333',
  },
  header: {
    fontSize: 24, 
    fontWeight: 'bold',
    color: '#333',
  },
  darkText: {
    color: '#fff',
  },
  switch: {
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 5,
    alignItems: 'center',
  },
  feedbackInput: {
    height: 100,
    borderColor: '#ccc',
    borderWidth: 1, 
    borderRadius: 5, 
    padding: 10,
    textAlignVertical: 'top',
  },
  faqsContainer: {
    marginTop: 20,
    width: '100%',
  },
  faqItem: {
    backgroundColor: '#f9f9f9',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  darkFaqItem: {
    backgroundColor: '#444',
  },
  darkFaqText: {
    color: '#fff',
  },
  input: {
    borderColor: '#ddd',
    borderWidth: 1,
    padding: 8,
    borderRadius: 4,
    minHeight: 80,
    width: '80%',
  },
  headerApp: { 
    alignItems: 'center', 
    marginBottom: 16, 
    justifyContent: 'center', 
  },
  logo: { 
    width: 120,
    height: 120, 
    borderRadius: 100,
    marginBottom: 8,
  },
  title: { 
    fontSize: 24, 
    fontWeight: 'bold' 
  },
  titleDark: { 
    fontSize: 24, 
    color: 'white',
    fontWeight: 'bold' 
  },
  switchContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 24, justifyContent: 'space-between' },
  label: { marginRight: 8, color: 'black' },
  labelDark: { marginRight: 8, color: 'white' },
  buttonContainer: { marginBottom: 16 },
  button: {
    backgroundColor: '#0077B6',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
    width: '80%',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  faqContainer: { marginTop: 16 },
  faqText: {
    padding: 8,
    backgroundColor: '#f0f0f0', 
    marginBottom: 8,
    borderRadius: 4,
    color: '#333', 
  },
  darkFaqText: {
    color: '#fff', 
  },
  darkFaqItem: {
    backgroundColor: '#444', 
  },
});

export default styles;
