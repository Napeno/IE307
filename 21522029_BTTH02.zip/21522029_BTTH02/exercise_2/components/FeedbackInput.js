import React from 'react';
import { TextInput, StyleSheet, TouchableWithoutFeedback, Keyboard, View } from 'react-native';
import styles from '../styles/settings';

export default function FeedbackInput({ feedback, setFeedback }) {
  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={{ alignItems: 'center', width: '100%', flex: 1 }}>
          <TextInput
            style={styles.input}
            placeholder="Nhập phản hồi của bạn..."
            value={feedback}
            onChangeText={setFeedback}
            multiline
          />
        </View>
    </TouchableWithoutFeedback>
  );
}
