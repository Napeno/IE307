import React from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
import styles from '../styles/settings'

export default function NotificationSwitch({ isNotificationsEnabled, setIsNotificationsEnabled, isDarkMode }) {
  return (
    <View style={styles.switchContainer}>
      <Text style={[styles.label, isDarkMode && styles.labelDark]}>Thông báo</Text>
      <Switch value={isNotificationsEnabled} onValueChange={setIsNotificationsEnabled} />
    </View>
  );
}
