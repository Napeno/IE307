import React from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
import styles from '../styles/settings'

export default function ThemeSwitch({ isDarkMode, setIsDarkMode }) {
  return (
    <View style={styles.switchContainer}>
      <Text style={[styles.label, isDarkMode && styles.labelDark]}>Chế độ tối</Text>
      <Switch value={isDarkMode} onValueChange={setIsDarkMode} />
    </View>
  );
}

