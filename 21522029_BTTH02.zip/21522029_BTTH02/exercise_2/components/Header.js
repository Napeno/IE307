import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import styles from '../styles/settings'

export default function Header({isDarkMode}) {
  return (
    <View style={styles.headerApp}>
       <Image 
        source={require('../assets/images/react-loga.png')} 
        style={styles.logo}
        />

      <Text style={[styles.title, isDarkMode && styles.titleDark]}>React Native Apps</Text>
    </View>
  );
}
