import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import styles from '../styles/settings'

export default function FAQs({ faqs, isDarkMode }) {
  return (
    <View style={styles.faqContainer}>
      {faqs.map((faq, index) => (
        <Text
          key={index}
          style={[styles.faqText, isDarkMode && styles.darkFaqText, isDarkMode && styles.darkFaqItem]}
        >
          {faq}
        </Text>
      ))}
    </View>
  );
}

