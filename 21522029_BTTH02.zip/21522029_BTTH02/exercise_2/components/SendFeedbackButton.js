import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import styles from '../styles/settings'

export default function SendFeedbackButton({ handleSendFeedback }) {
  return (
    <View style={styles.buttonContainer}>
      <TouchableOpacity style={styles.button} onPress={handleSendFeedback}>
        <Text style={styles.buttonText}>Send Feedback</Text>
      </TouchableOpacity>
    </View>
  );
}


