// NGUYỄN SƠN HÀ 21522029

import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Alert, Text } from 'react-native';
import Header from '../components/Header';
import ThemeSwitch from '../components/ThemeSwitch';
import NotificationSwitch from '../components/NotificationSwitch';
import FeedbackInput from '../components/FeedbackInput';
import SendFeedbackButton from '../components/SendFeedbackButton';
import FAQs from '../components/FAQs';
import styles from '../styles/settings';

export default function Settings() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true);
  const [feedback, setFeedback] = useState('');
  const [faqs, setFaqs] = useState<string[]>([]);

  const handleSendFeedback = () => {
    if (feedback.trim() === '') return;
    setFaqs([feedback, ...faqs]);
    setFeedback('');
    if (isNotificationsEnabled) {
      Alert.alert('Thank you for your feedback');
    }
  };

  return (
    <View style={[styles.container, isDarkMode && styles.darkContainer]}>
      <Header isDarkMode={isDarkMode}/>
      <ThemeSwitch isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />
      <NotificationSwitch isNotificationsEnabled={isNotificationsEnabled} setIsNotificationsEnabled={setIsNotificationsEnabled} isDarkMode={isDarkMode} />
      <Text style={[styles.header, isDarkMode && styles.darkText]}>Feedback</Text>
      <FeedbackInput feedback={feedback} setFeedback={setFeedback} />
      <SendFeedbackButton handleSendFeedback={handleSendFeedback} />
      <Text style={[styles.header, isDarkMode && styles.darkText]}>Frequently Asked Questions</Text>
      <ScrollView>
        <FAQs faqs={faqs} isDarkMode={isDarkMode} />
      </ScrollView>
    </View>
  );
}
